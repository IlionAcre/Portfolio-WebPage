function adjustLine(containerId, lineContainerId, direction = 'left') {
  const container = document.getElementById(containerId);
  const line = document.getElementById(lineContainerId);

  if (!container || !line) {
      console.error(`Container or line element not found: ${containerId}, ${lineContainerId}`);
      return;
  }

  const width = container.offsetWidth;
  const height = container.offsetHeight;

  // Assuming the width and height provide the dimensions of the entire area to cover
  let lineLength = Math.sqrt((width / 2) ** 2 + height ** 2); // This remains correct for reaching the bottom-center
  
  let angle;
  if (direction === 'left') {
      // Angle for left direct                ion remains unchanged
      angle = Math.atan2(height, width / 2) * (180 / Math.PI) - 0.2;
      line.style.transformOrigin = 'top left';
      line.style.left = '0px'; // Ensure it starts from the top-left
  } else {
      // Correcting angle for the right direction
      // This needs to ensure it points diagonally towards the bottom-center
      angle = - (Math.atan2(height, width / 2) * (180 / Math.PI)) + 0.2;
      line.style.transformOrigin = 'top right';
      line.style.right = '0px'; // Ensure it starts from the top-right
  }

  line.style.position = 'absolute';
  line.style.width = `${lineLength}px`;
  line.style.top = '0px';
  line.style.transform = `rotate(${angle}deg)`;

}

// Improved window resize event handling
function setupResizeListener(containerId, lineContainerId, direction) {
  window.addEventListener('resize', () => adjustLine(containerId, lineContainerId, direction));
}

// Setup for both lines
adjustLine("triangle1", "triangle1-left", 'left');
adjustLine("triangle1", "triangle1-right", 'right');

adjustLine("triangle2", "triangle2-left", 'left');
adjustLine("triangle2", "triangle2-right", 'right');

// Setup resize listeners for dynamic adjustment
setupResizeListener("triangle1", "triangle1-left", 'left');
setupResizeListener("triangle1", "triangle1-right", 'right');

setupResizeListener("triangle2", "triangle2-left", 'left');
setupResizeListener("triangle2", "triangle2-right", 'right');


// Filter buttons

const skillsContainer = document.querySelector(".skills-wrapper");


const allBtn = skillsContainer.querySelector(".all") 
const allBtns = skillsContainer.querySelectorAll(".all") 

function checkAll(){
  const allButtons = skillsContainer.querySelectorAll(".btn-check:not(.all)");
  for (const item of allButtons) {
    if (!item.classList.contains("btn-check--checked")){
      console.log(item.classList);
      return false;
    }
  };
  return true;
}

function filterSkills() {
  const skillCards = document.querySelectorAll(".skill-card");

  // Determine the active filters
  const activeFilters = [];
  if (skillsContainer.querySelector(".technical").classList.contains("btn-check--checked")) {
    activeFilters.push("technical");
  }
  if (skillsContainer.querySelector(".soft").classList.contains("btn-check--checked")) {
    activeFilters.push("soft");
  }

  // If "All" is checked or no specific filters are active, show all skills
  if (activeFilters.length === 0 || skillsContainer.querySelector(".all").classList.contains("btn-check--checked")) {
    skillCards.forEach(card => {
      card.style.display = "flex";
    });
  } else {
    // Filter the skill cards based on the active filters
    skillCards.forEach(card => {
      const skillType = card.getAttribute("data-type");
      if (activeFilters.includes(skillType)) {
        card.style.display = "flex";
      } else {
        card.style.display = "none";
      }
    });
  }
}

function toggleCheckbox(tag) {
  // Get all buttons of the specified type (e.g., all technical or all soft)
  const targetButtons = skillsContainer.querySelectorAll(tag);
  
  // Remove the checked state from all buttons
  const allButtons = skillsContainer.querySelectorAll(".btn-check");
  allButtons.forEach(button => {
    button.classList.remove("btn-check--checked");
  });

  // Add the checked state only to the clicked button's group
  targetButtons.forEach(button => {
    button.classList.add("btn-check--checked");
  });

  // Run the filtering logic after updating the button states
  filterSkills();
}

function filterSkills() {
  const skillCards = document.querySelectorAll(".skill-card");

  // Determine which filter is active
  let activeFilter = null;
  if (skillsContainer.querySelector(".technical").classList.contains("btn-check--checked")) {
    activeFilter = "technical";
  } else if (skillsContainer.querySelector(".soft").classList.contains("btn-check--checked")) {
    activeFilter = "soft";
  } else if (skillsContainer.querySelector(".all").classList.contains("btn-check--checked")) {
    activeFilter = "all";
  }

  // Show/hide skill cards based on the active filter
  if (activeFilter === "all" || activeFilter === null) {
    // Show all skills if "All" is active or if no filter is selected
    skillCards.forEach(card => {
      card.style.display = "flex";
    });
  } else {
    // Show only the skills that match the active filter type
    skillCards.forEach(card => {
      const skillType = card.getAttribute("data-type");
      if (skillType === activeFilter) {
        card.style.display = "flex";
      } else {
        card.style.display = "none";
      }
    });
  }
}


function toggleLight(element) {
  element.classList.toggle("enlightened");
}

function toggleTextLight(element) {
  element.classList.toggle("enlightened-text");
}

function toggleTitleLight(element) {
  element.classList.toggle("enlightened-title");
}


//nav-bar

const primaryNav = document.querySelector(".nav-list");
const navToggle = document.querySelector(".mobile-nav-toggle");

navToggle.addEventListener("click", () => {
  const visibility = primaryNav.getAttribute("data-visible");
  if (visibility === "false") {
    primaryNav.setAttribute("data-visible", true);
    navToggle.setAttribute("area-expanded", true);
  } else {
    primaryNav.setAttribute("data-visible", false);
    navToggle.setAttribute("area-expanded", false);
  }


});

document.addEventListener('DOMContentLoaded', function () {
  filterSkills();
});